#!/usr/bin/env python3
"""
Lunisolar OS calendar generator.

Generates an iPhone-friendly .ics calendar that overlays:
- lunar phase windows with guidance (multi-day bars)
- key phase marker days (New/First/Full/Third)
- equinoxes/solstices
- optional Wheel-of-the-Year cross-quarter markers

Moon phase timing is APPROXIMATE (sufficient for day-level planning).
If you need astronomy-grade accuracy, replace the phase engine with Skyfield.

Usage:
  python3 src/generate_lunisolar_os.py --year 2026 --out calendar/lunisolar_os_2026.ics
"""

from __future__ import annotations

import argparse
import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone, date
from typing import List, Tuple

# --- Julian Day conversions (UTC) ---

def datetime_to_jd(dt: datetime) -> float:
    if dt.tzinfo is None:
        raise ValueError("dt must be timezone-aware")
    dt = dt.astimezone(timezone.utc)

    y = dt.year
    m = dt.month
    D = dt.day + (dt.hour + (dt.minute + dt.second / 60) / 60) / 24

    if m <= 2:
        y -= 1
        m += 12

    A = y // 100
    B = 2 - A + (A // 4)

    jd = int(365.25 * (y + 4716)) + int(30.6001 * (m + 1)) + D + B - 1524.5
    return jd


def jd_to_datetime(jd: float) -> datetime:
    jd += 0.5
    Z = int(jd)
    F = jd - Z

    if Z < 2299161:
        A = Z
    else:
        alpha = int((Z - 1867216.25) / 36524.25)
        A = Z + 1 + alpha - int(alpha / 4)

    B = A + 1524
    C = int((B - 122.1) / 365.25)
    D = int(365.25 * C)
    E = int((B - D) / 30.6001)

    day = B - D - int(30.6001 * E) + F
    month = E - 1 if E < 14 else E - 13
    year = C - 4716 if month > 2 else C - 4715

    day_int = int(day)
    frac = day - day_int

    hours = frac * 24
    hour = int(hours)
    minutes = (hours - hour) * 60
    minute = int(minutes)
    seconds = (minutes - minute) * 60
    second = int(seconds)
    micro = int((seconds - second) * 1_000_000)

    return datetime(year, month, day_int, hour, minute, second, micro, tzinfo=timezone.utc)


# --- Moon phase approximation ---
EPOCH_NEW_MOON_JD = 2451550.09765  # 2000-01-06 18:14 UT (approx)
SYNODIC_MONTH = 29.530588853

PHASE_OFFSETS = {
    "New Moon": 0.00,
    "First Quarter": 0.25,
    "Full Moon": 0.50,
    "Third Quarter": 0.75,
}

WINDOW_GUIDANCE = {
    ("New Moon", "First Quarter"): ("🌑→🌓 Build", "Waxing Crescent",
        "Set intentions, plan your week, and define 1–3 process goals.\n"
        "Trading: finalize rules, mark levels, pre‑commit risk limits.\n"
        "Keep it clean: simple actions that compound."),
    ("First Quarter", "Full Moon"): ("🌓→🌕 Execute", "Waxing Gibbous",
        "Execution + discipline.\n"
        "Trading: A+ setups only, strict risk, no revenge trades.\n"
        "Build reps, not excitement. Track mistakes like a scientist."),
    ("Full Moon", "Third Quarter"): ("🌕→🌗 Review", "Waning Gibbous",
        "Reflection and truth.\n"
        "Trading: review winners/losers, extract 1 lesson, reduce noise.\n"
        "Journal insights. Release emotional residue."),
    ("Third Quarter", "New Moon"): ("🌗→🌑 Refine", "Waning Crescent",
        "Prune and reset.\n"
        "Trading: simplify watchlist, cut weak habits, lower size if needed.\n"
        "Protect sleep/energy. Prepare the next cycle."),
}

PHASE_DAY_GUIDANCE = {
    "New Moon": ("🌑 New Moon — Plan",
        "Planning + intentions.\n"
        "Write 3 priorities, define risk rules, and choose the smallest daily actions that compound."),
    "First Quarter": ("🌓 First Quarter — Commit",
        "Commit to action.\n"
        "Execute your process. One day at a time. No perfectionism."),
    "Full Moon": ("🌕 Full Moon — Reveal",
        "Clarity + truth.\n"
        "Review the cycle, journal insights, and release what’s weighing you down."),
    "Third Quarter": ("🌗 Third Quarter — Edit",
        "Course‑correct.\n"
        "Reduce noise, refine rules, and protect sleep/energy."),
}

SEASONAL_MARKERS = {
    # Approximate day-level markers (fine for lifestyle planning)
    "March Equinox": (3, 20),
    "June Solstice": (6, 21),
    "September Equinox": (9, 23),
    "December Solstice": (12, 21),
}

WHEEL_MARKERS = [
    ((2, 1), "🔥 Imbolc (cross‑quarter)",
     "First stirrings of spring. Commit to small daily practice; momentum builds quietly."),
    ((5, 1), "🌼 Beltane (cross‑quarter)",
     "Growth + vitality. Expand what works; celebrate progress; keep boundaries."),
    ((8, 1), "🌾 Lughnasadh (cross‑quarter)",
     "First harvest. Measure results, harvest lessons, refine strategy."),
    ((11, 1), "🕯 Samhain (cross‑quarter)",
     "Threshold season. Close loops, let go of dead weight, simplify."),
]


def lunar_phases_for_year(year: int) -> List[Tuple[datetime, str]]:
    start = datetime(year, 1, 1, tzinfo=timezone.utc)
    end = datetime(year + 1, 1, 1, tzinfo=timezone.utc)

    jd_start = datetime_to_jd(start)
    jd_end = datetime_to_jd(end)

    k_start = math.floor((jd_start - EPOCH_NEW_MOON_JD) / SYNODIC_MONTH) - 2
    k_end = math.ceil((jd_end - EPOCH_NEW_MOON_JD) / SYNODIC_MONTH) + 2

    events: List[Tuple[datetime, str]] = []
    for k in range(k_start, k_end + 1):
        base_new = EPOCH_NEW_MOON_JD + k * SYNODIC_MONTH
        for phase, off in PHASE_OFFSETS.items():
            jd = base_new + off * SYNODIC_MONTH
            dt = jd_to_datetime(jd)
            if start <= dt < end:
                events.append((dt, phase))
    events.sort(key=lambda x: x[0])
    return events


def ics_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;")


def format_date(d: date) -> str:
    return d.strftime("%Y%m%d")


def generate_ics(year: int, include_wheel: bool) -> str:
    events = lunar_phases_for_year(year)
    points = [(dt.date(), phase) for dt, phase in events]
    points.sort()

    nowstamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Lunisolar OS//Calendar Generator//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
    ]

    uid_i = 1

    def add_all_day(summary: str, desc: str, start_d: date, end_excl: date) -> None:
        nonlocal uid_i
        lines.extend([
            "BEGIN:VEVENT",
            f"UID:lunisolar-os-{uid_i}@lunisolar-os",
            f"DTSTAMP:{nowstamp}",
            f"DTSTART;VALUE=DATE:{format_date(start_d)}",
            f"DTEND;VALUE=DATE:{format_date(end_excl)}",
            f"SUMMARY:{ics_escape(summary)}",
            f"DESCRIPTION:{ics_escape(desc)}",
            "END:VEVENT"
        ])
        uid_i += 1

    # Phase windows (multi-day bars)
    for i in range(len(points) - 1):
        s_date, s_phase = points[i]
        e_date, e_phase = points[i + 1]
        key = (s_phase, e_phase)
        if key in WINDOW_GUIDANCE and s_date < e_date:
            title, name, desc = WINDOW_GUIDANCE[key]
            add_all_day(
                f"{title} — {name}",
                desc + "\n\nPersonal anchor:\n- Protect clarity with sleep, food, movement.\n- Trading: process > outcome.\n- Journal nightly: win, lesson, next step.",
                s_date,
                e_date
            )

    # Single-day phase markers
    seen = set()
    for dt, phase in events:
        d0 = dt.date()
        k = (d0, phase)
        if k in seen:
            continue
        seen.add(k)
        title, desc = PHASE_DAY_GUIDANCE[phase]
        add_all_day(title, desc, d0, d0 + timedelta(days=1))

    # Seasonal markers
    add_all_day("☀️ March Equinox", "Balance point. Clean reset: choose what you’re becoming; build routines that make it inevitable.",
                date(year, 3, 20), date(year, 3, 21))
    add_all_day("☀️ June Solstice", "Peak light. Max output. Guard against overtrading—channel power into process.",
                date(year, 6, 21), date(year, 6, 22))
    add_all_day("☀️ September Equinox", "Second balance. Audit systems: what’s working? Re‑align goals for the rest of the year.",
                date(year, 9, 23), date(year, 9, 24))
    add_all_day("☀️ December Solstice", "Deep reset. Review the year; design the next. Rest is strategy.",
                date(year, 12, 21), date(year, 12, 22))

    # Wheel of the year (optional)
    if include_wheel:
        for (m, d), title, desc in WHEEL_MARKERS:
            add_all_day(title, desc, date(year, m, d), date(year, m, d) + timedelta(days=1))

    lines.append("END:VCALENDAR")
    return "\r\n".join(lines) + "\r\n"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--year", type=int, required=True, help="Year to generate, e.g., 2026")
    p.add_argument("--out", type=str, required=True, help="Output .ics path")
    p.add_argument("--no-wheel", action="store_true", help="Disable Wheel-of-the-Year cross-quarter markers")
    args = p.parse_args()

    ics = generate_ics(args.year, include_wheel=not args.no_wheel)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(ics)

    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
